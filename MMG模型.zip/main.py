import numpy as np
from scipy.integrate import solve_ivp


# 定义运动方程
def mmg_model(t, state, params):
    u, v, r = state
    m, Iz, X_H, Y_H, N_H = params

    # 船体力
    Xu, Xuu = X_H
    X = -Xu * u - Xuu * abs(u) * u

    # 横向力
    Yv, Yr = Y_H
    Y = -Yv * v - Yr * r

    # 力矩
    Nr, Nv = N_H
    N = -Nr * r - Nv * v

    # 方程
    du_dt = (X + m * v * r) / m
    dv_dt = (Y - m * u * r) / m
    dr_dt = N / Iz
    return [du_dt, dv_dt, dr_dt]


# 初始条件
state0 = [1.0, 0.0, 0.0]  # u, v, r 初值
params = [500, 1000, [50, 10], [30, 20], [15, 5]]  # 参数

# 时间积分
t_span = (0, 100)
sol = solve_ivp(mmg_model, t_span, state0, args=(params,), dense_output=True)

# 可视化结果
import matplotlib.pyplot as plt

t = np.linspace(0, 100, 500)
state = sol.sol(t)
plt.plot(t, state[0], label="u (纵向速度)")
plt.plot(t, state[1], label="v (横向速度)")
plt.plot(t, state[2], label="r (角速度)")
plt.legend()
plt.xlabel("Time (s)")
plt.ylabel("State")
plt.show()

