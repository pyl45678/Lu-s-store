import math
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from scipy import linalg
"""
rho ：水密度
s ：湿表面积
viscosity : 动力粘度
"""

rho = 1000  # kg/m³
Lpp7 = 7
s7 = 13.0129
s3 = s7 / (7 / 2.902) ** 2
d7 = 0.46
U7 = 1.18
Lpp3 = 2.902
d3 = 0.189
U3 = 0.76
R0_prime3 = 0.022
viscosity = 1.01 * 10 ** -6
Rt3 = R0_prime3 * (1 / 2) * rho * Lpp3 * d3 * U3 ** 2
Ct3 = Rt3 / ((1 / 2) * rho * s3 * U3 ** 2)
Re3 = U3 * Lpp3 / viscosity
Cf3 = 0.4631 / (math.log(Re3, 10)) ** 2.6
Cw3 = Ct3 - Cf3
Cw7 = Cw3
Re7 = U7 * Lpp7 / viscosity
Cf7 = 0.4631 / (math.log(Re7, 10)) ** 2.6
Ct7 = Cw7 + Cf7
Rt7 = Ct7 * (1 / 2) * rho * s7 * U7 ** 2
R0_prime7 = Rt7 / ((1 / 2) * rho * Lpp7 * d7 * U7 ** 2)
print("R0_prime7:", R0_prime7)

tp = 0.22
Xp = Rt7
T = Xp / (1-tp)
k0 = 0.2931
k1 = -0.2753
k2 = -0.1385
beta = 0
r_prime = 0
wp0 = 0.4
Dp = 0.216
u7 = U7
delta = 0
dt = 0.05
summ = 0

# 给定条件
Xvv_prime = -0.04
Xvr_prime = 0.002
Xrr_prime = 0.011
Xvvvv_prime = 0.771
Yv_prime = -0.315
YR_prime = 0.083
Yvvv_prime = -1.607
Yvvr_prime = 0.379
Yvrr_prime = -0.391
Yrrr_prime = 0.008
Nv_prime = -0.137
NR_prime = -0.049
Nvvv_prime = -0.03
Nvvr_prime = -0.294
Nvrr_prime = 0.055
Nrrr_prime = -0.013
C1 = 2
xp_prime = -1
HR = 0.345  #
n = Dp / HR
fa = 2.747
AR = 0.0539  #
tR = 0.387
lR_prime = -0.710
e = 1.09
k = 0.5
aH = 0.312
xR = -0.5 * Lpp7
xH = -0.45 * Lpp7
xR_prime = -0.5
xH_prime = -0.464

def solve_quadratic(a, b, c):
    discriminant = b ** 2 - 4 * a * c

    if discriminant > 0:
        root1 = (-b + discriminant**0.5) / (2*a)
        root2 = (-b - discriminant**0.5) / (2*a)
        return root1, root2
    elif discriminant == 0:
        root = -b / (2*a)
        return root, root
    else:
        real_part = -b / (2*a)
        imaginary_part = (-discriminant)**0.5 / (2*a)
        root1 = complex(real_part, imaginary_part)
        root2 = complex(real_part, -imaginary_part)
        return root1, root2

# 输入系数
a = k0
b = k1 * u7 * (1-wp0) / Dp
c = -T/(rho * Dp ** 4) + (k2 * u7 ** 2 * (1-wp0)/Dp ** 2)

# 调用函数解方程
solution = solve_quadratic(a, b, c)
for i in range(len(solution)):
    if solution[i] > 0:
        Np = solution[i]
print("np:", Np)

#  给船舶运动状态赋初值
c = 0
xe = 0
ye = 0
U = 1.18
r = 0
u = U * math.cos(beta)
vm = -U * math.sin(beta)
Xe = []
Ye = []
idx = 0

# 循环更新船舶位置
while summ < 540 * math.pi / 180:
    idx += 1
    delta = delta - 11.9 * math.pi / 180 * dt
    if abs(delta) >= -35 * math.pi / 180:
        delta = -35 * math.pi / 180

    # 船体受力
    vm_prime = vm / U
    r_prime = r * Lpp7 / U

    # 计算 XH
    def XH_prime(vm_prime, r_prime):
        return -R0_prime7 + Xvv_prime * vm_prime ** 2 + Xvr_prime * vm_prime * r_prime + Xrr_prime * r_prime ** 2 + Xvvvv_prime * vm_prime ** 4


    XH = (1 / 2) * rho * Lpp7 * d7 * U ** 2 * XH_prime(vm_prime, r_prime)


    # 计算 YH
    def YH_prime(vm_prime, r_prime):
        return Yv_prime * vm_prime + YR_prime * r_prime + Yvvv_prime * vm_prime ** 3 + Yvvr_prime * vm_prime ** 2 * r_prime + Yvrr_prime * vm_prime * r_prime ** 2 + Yrrr_prime * r_prime ** 3


    YH = (1 / 2) * rho * Lpp7 * d7 * U ** 2 * YH_prime(vm_prime, r_prime)


    # 计算 NH
    def NH_prime(vm_prime, r_prime):
        return Nv_prime * vm_prime + NR_prime * r_prime + Nvvv_prime * vm_prime ** 3 + Nvvr_prime * vm_prime ** 2 * r_prime + Nvrr_prime * vm_prime * r_prime ** 2 + Nrrr_prime * r_prime ** 3


    NH = (1 / 2) * rho * Lpp7 ** 2 * d7 * U ** 2 * NH_prime(vm_prime, r_prime)

    # 螺旋桨受力
    beta_p = beta - xp_prime * r_prime
    # 根据 beta_p 的值设置 C2
    if beta_p > 0:
        C2 = 1.6
    else:
        C2 = 1.1
    # 计算 wp
    wp = 1 -((1 + (1 - math.exp(-C1 * abs(beta_p))) * (C2 - 1)) * (1 - 0.4))
    # 计算 Jp
    Jp = u * (1 - wp) / (Np * Dp)
    # 计算 KT_Jp
    KT_Jp = k2 * Jp ** 2 + k1 * Jp + k0
    # 计算 T
    # 错误：T = (rho * np ** 2 * Dp ** 4 * KT_Jp)/((1 / 2) * rho * Lpp * d * U ** 2 )
    # 错误：print("T:", T)
    T = rho * Np ** 2 * Dp ** 4 * KT_Jp
    # 计算 Xp
    XP = (1 - tp) * T

    # 舵受力
    # 计算 betaR
    beta_R = beta - lR_prime * r_prime
    if beta_R > 0:
        yR = 0.64
    else:
        yR = 0.395

    # 计算 vR
    vR = U * yR * beta_R
    # 计算 uR
    uR = e * u * (1 - wp) * math.sqrt(n * (1 + k * (math.sqrt(1 + 8 * KT_Jp / (math.pi * Jp ** 2)) - 1)) ** 2 + (1 - n))
    # 计算 aR
    aR = delta - vR / uR
    # 计算 UR
    UR = math.sqrt(uR ** 2 + vR ** 2)
    # 计算 FN
    # 错误：FN = (0.5 * rho * AR * UR ** 2 * fa * math.sin(aR))/(0.5 * rho * Lpp * d * U ** 2)
    # 错误：print("FN:", FN)
    FN = 0.5 * rho * AR * UR ** 2 * fa * math.sin(aR)
    # 计算 XR
    XR = -(1 - tR) * FN * math.sin(delta)
    YR = -(1 + aH) * FN * math.cos(delta)
    NR = -(xR + aH * xH) * FN * math.cos(delta)
    print(XH, XR, XP)
    # 船舶总体受力
    X = XH + XR + XP
    Y = YH + YR
    Nm = NH + NR
    # 错误：Nm = (NH+NR) / ((1 / 2) * rho * Lpp * d * U ** 2)
    print(X,Y,Nm)

    # 加速度
    displacement_volume = 3.27  #
    mx_prime = 0.022
    my_prime = 0.223
    jz_prime = 0.011
    xG = 0.25
    m = displacement_volume * rho
    IzG = m * (0.25 * Lpp7) ** 2
    mx = (1 / 2) * rho * Lpp7 ** 2 * d7 * mx_prime
    my = (1 / 2) * rho * Lpp7 ** 2 * d7 * my_prime
    jz = (1 / 2) * rho * Lpp7 ** 4 * d7 * jz_prime
    du = (X + xG * m * r ** 2 + (m + my) * vm * r) / (m + mx)
    A = [[m + my, m * xG], [m * xG, IzG + m * (xG ** 2) + jz]]
    B = [Y - (m + mx) * u * r, Nm - xG * m * u * r]
    [dvm, dr] = linalg.solve(A , B)

    u += du * dt
    vm += dvm * dt
    r += dr * dt
    summ = summ + abs(r * dt)
    beta = math.atan(-vm / u)
    U = math.sqrt(u ** 2 + vm ** 2)
    c += r * dt
    xe = xe + (u * math.cos(c) - vm * math.sin(c)) * dt
    ye = ye + (u * math.sin(c) + vm * math.cos(c)) * dt

    print(xe, ye)
    # 将计算结果存入数组
    Xe.append(xe)
    Ye.append(ye)


# 创建 DataFrame 对象
df = pd.DataFrame({'xe': Xe, 'ye': Ye})

# 创建 DataFrame 对象
df = pd.DataFrame({'xe': Xe, 'ye': Ye})
# 将 DataFrame 写入 Excel 文件
df.to_excel("回转试验1.xlsx", index=False)
# 绘制图像
plt.plot(Y, X, '--', label='Exp')
xmax = max(Xe)
ymax = max(Ye)
print(xmax, ymax)
plt.plot(Ye, Xe, label='Sim')
plt.xlabel('Ye/L [-]')
plt.ylabel('Xe/L [-]')
plt.legend()
plt.show()


